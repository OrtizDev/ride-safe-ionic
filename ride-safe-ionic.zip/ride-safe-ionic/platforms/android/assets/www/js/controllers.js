angular.module('app.controllers', [])

.controller('loginCtrl', ['$scope', '$stateParams', '$state', 'UserSession', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, UserSession) {

    $scope.formData = {};
    $scope.login = function () {

        var email = $("#emailLogin").val();
        var password = $("#passwordLogin").val();
        alert(email);
        if (email == '') {
            alert("Por favor, ingresa tu correo");
        } else {
            var valid = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/;
            var validcor = new RegExp(valid);
            var matchArray = email.match(validcor);
            if (matchArray == null) {
                alert("Por favor, ingresa un correo valido");
            }
            else {
                if (password == '') {
                    alert("Por favor, ingresa tu contrase�a");
                } else {
                    var parametros = {
                        "email": email,
                        "password": password
                    };
                    $.ajax({
                        type: "POST",
                        url: "http://startbluesoft.com/rideSafeApp/v1/index.php/userlogin",
                        data: parametros,
                        dataType: "json",
                        success: function (data) {
                            if (data.error) {
                                alert(data.message);
                            } else if (!data.error) {
                                UserSession.setData(data.id);
                                $state.go('home');
                            }
                        },
                        error: function (xhr, status, error) {
                            console.log(xhr.responseText);
                            alert("No se pudo iniciar sesi�n, int�ntalo m�s tarde");
                        }
                    });
                }
            }
        }
    }

}])

.controller('graciasCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])

.controller('page3Ctrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {



}])

.controller('homeCtrl', ['$scope', '$stateParams', 'UserSession', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, UserSession) {
    var id = UserSession.getData();


}])

.controller('manualCtrl', ['$scope', '$stateParams', '$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state) {

    $scope.returnHome = function () {
        $state.go('home');
    }

}])

.controller('sR2ProtectionCtrl', ['$scope', '$stateParams', 'S2R', '$ionicHistory', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, S2R, $ionicHistory) {

        $scope.$on('$ionicView.enter', function () {
            var IC = S2R.getEstateS2R_IC();
            var DR = S2R.getEstateS2R_DR();
            var AR = S2R.getEstateS2R_AR();
            var LT = S2R.getEstateS2R_LT();
            var MC = S2R.getEstateS2R_MC();
            var HP = S2R.getEstateS2R_HP();
            if (IC == "true") {
                $scope.pushNotiIC = { checked: true };
                console.log("ic " + IC);
            } else {
                $scope.pushNotiIC = { checked: false };
            }

            if (DR == "true") {
                $scope.pushNotiDR = { checked: true };
                console.log("DR " + DR);
            } else {
                $scope.pushNotiDR = { checked: false };
            }

            if (AR == "true") {
                $scope.pushNotiAR = { checked: true };
                console.log("AR" + AR);
            } else {
                $scope.pushNotiAR = { checked: false };
            }

            if (LT == "true") {
                $scope.pushNotiLT = { checked: true };
                console.log("LT" + LT);
            } else {
                $scope.pushNotiLT = { checked: false };
            }

            if (MC == "true") {
                $scope.pushNotiMC = { checked: true };
                console.log("MC" + MC);
            } else {
                $scope.pushNotiMC = { checked: false };
            }

            if (HP == "true") {
                $scope.pushNotiHP = { checked: true };
                console.log("HP" + HP);
            } else {
                $scope.pushNotiHP = { checked: false };
            }

        });

    $scope.saveNoti = function () {
        S2R.setEstateS2R($scope.pushNotiIC.checked,
                         $scope.pushNotiDR.checked,
                         $scope.pushNotiAR.checked,
                         $scope.pushNotiLT.checked,
                         $scope.pushNotiMC.checked,
                         $scope.pushNotiHP.checked);
    }

    $scope.backS2R = function () {
        $ionicHistory.goBack();
    }

}])

.controller('descubrirRutaCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])

.controller('nuevaRutaCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])

.controller('misRutasCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])

.controller('grabarRutasCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])

.controller('preRutasCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])

.controller('menuCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])

.controller('menuItemsCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
